# 分享卡片系统详细设计

## 1. 概述

分享卡片系统让学员在训练完成后，一键生成精美的训练总结卡片，保存到手机相册或复制链接，发到微信群/朋友圈进行"打卡"展示。

### 1.1 平台兼容策略

| 平台               | 用户占比 | 保存方式                      |
| ------------------ | -------- | ----------------------------- |
| **移动端（优先）** | ~90%     | Web Share API → 原生分享/保存 |
| **桌面端**         | ~10%     | 自动下载 PNG 文件             |

### 1.2 裂变增长元素（核心）

卡片用于"晒训练"，引导新用户了解平台：

| 元素         | 作用                            | 实现                   |
| ------------ | ------------------------------- | ---------------------- |
| **扫码入口** | 路人扫码查看训练详情 → 了解平台 | 二维码链接到公开分享页 |
| **教练露出** | 教练品牌曝光                    | "跟随教练 XX 训练"     |
| **挑战文案** | 激发好奇心                      | "今日训练 12,450 kg"   |
| **品牌曝光** | 平台认知                        | CoachLink Logo         |

> **注**：暂不做推荐奖励系统，初期仅支持纯粹的社交分享。

### 1.3 后期扩展 (Growth Roadmap)

虽然 MVP 阶段不实现奖励，但设计上预留以下扩展性：

1. **推荐奖励 (Referral Rewards)**：
   - 扫码链接带 `?ref=userId`。
   - 新用户通过此链接注册，推荐人可获得：1个月会员、训练计划折扣券、或虚拟勋章。
2. **支付集成**：
   - 与订阅系统对接，自动计算推荐返利。
3. **数据沉淀**：
   - 记录通过分享带来的拉新数（转化漏斗）。

---

## 2. 卡片模板设计

提供 3 款风格不同的卡片模板供用户选择：

### 2.1 数据流模板（默认）

**风格**：深色渐变背景 + 霓虹色彩 + 玻璃态卡片

![数据流卡片](assets/share_card_data_style.png)

**内容展示**：

- 用户头像 + 昵称
- **核心数据**：总容量（kg）、总组数、训练时长
- **亮点**：今日 PR 记录（如：🔥 卧推 85kg）
- 底部：CoachLink Logo + 二维码

**适用场景**：数据控、力量训练爱好者

---

### 2.2 日历流模板

**风格**：暗色主题 + GitHub 风格热力图

![日历流卡片](assets/share_card_calendar_style.png)

**内容展示**：

- 当月训练热力图（绿色表示训练日）
- 今日打勾标记
- 连续打卡天数、本月训练天数
- 今日训练标题

**适用场景**：坚持打卡党、强调习惯养成

---

### 2.3 极简模板

**风格**：全屏健身背景图 + 大字标题

![极简卡片](assets/share_card_minimal_style.png)

**内容展示**：

- "DAY X" 大标题
- 训练名称
- 完成标记 ✓

**适用场景**：追求视觉冲击力、激励型分享

---

## 3. 技术实现方案

### 3.1 核心技术：html2canvas

```typescript
// 动态导入（Next.js SSR 兼容）
const html2canvas = await import("html2canvas");

// 生成图片
const canvas = await html2canvas.default(cardElement, {
    backgroundColor: null, // 透明背景
    scale: 2, // 2倍分辨率，保证清晰度
    useCORS: true, // 允许跨域图片
    logging: false,
});

// 转为 Blob
const blob = await new Promise<Blob>((resolve) => {
    canvas.toBlob((b) => resolve(b!), "image/png", 1.0);
});
```

### 3.2 保存到设备

**方案 A：Web Share API（推荐，移动端优先）**

```typescript
async function shareCard(blob: Blob, filename: string) {
    const file = new File([blob], filename, { type: "image/png" });

    if (navigator.canShare?.({ files: [file] })) {
        // 移动端原生分享
        await navigator.share({
            files: [file],
            title: "我的训练打卡",
        });
    } else {
        // 回退：下载文件
        downloadBlob(blob, filename);
    }
}
```

**方案 B：直接下载（桌面端回退）**

```typescript
function downloadBlob(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}
```

### 3.3 移动端保存到相册

在 PWA 或 WebView 环境下：

- **iOS Safari**：长按图片 → "添加到照片"
- **Android Chrome**：Web Share API 自动支持保存到相册
- **微信内置浏览器**：长按图片保存（需确保图片是 `<img>` 标签）

**最佳实践**：生成后先展示预览图，用户长按即可保存。

---

## 4. 组件架构

```
src/components/share/
├── ShareCardModal.tsx       # 分享弹窗（入口）
├── ShareCardPreview.tsx     # 卡片预览容器
├── templates/
│   ├── DataFlowCard.tsx     # 数据流模板
│   ├── CalendarCard.tsx     # 日历流模板
│   └── MinimalCard.tsx      # 极简模板
├── hooks/
│   └── useCardGenerator.ts  # 图片生成 Hook
└── utils/
    └── shareUtils.ts        # 分享工具函数
```

### 4.1 ShareCardModal 使用示例

```tsx
<ShareCardModal
  isOpen={showShareModal}
  onClose={() => setShowShareModal(false)}
  executionData={{
    dayIndex: 24,
    planName: "胸肌力量训练",
    totalVolume: 12450,
    totalSets: 24,
    duration: 45,
    prRecords: [{ exercise: "卧推", weight: 85 }],
    calendarData: [...], // 当月训练日期数组
  }}
  userProfile={{
    nickname: "锦恢",
    avatarUrl: "...",
  }}
/>
```

---

## 5. 数据接口

### 5.1 获取分享所需数据

**API**: `GET /api/execution/[id]/share-info`

**响应**:

```json
{
  "success": true,
  "data": {
    "executionId": "uuid",
    "shareToken": "uuid",
    "dayIndex": 24,
    "planName": "胸肌力量训练",
    "completedAt": "2026-01-04T01:30:00Z",
    "totalVolume": 12450,
    "totalSets": 24,
    "duration": 45,
    "prRecords": [
      { "exercise": "卧推", "weight": 85, "unit": "kg" }
    ],
    "monthlyTrainingDays": ["2026-01-02", "2026-01-04", ...],
    "user": {
      "nickname": "锦恢",
      "avatarUrl": "..."
    }
  }
}
```

### 5.2 公开分享页数据

**API**: `GET /api/public/training/[shareToken]`

无需登录即可访问，返回简化的训练摘要。

---

## 6. 用户流程

```
训练完成
    ↓
结算页展示 "分享打卡" 按钮
    ↓
点击弹出 ShareCardModal
    ↓
选择卡片模板（左右滑动切换）
    ↓
点击 "保存图片"
    ↓
├── 移动端：Web Share API → 分享/保存
└── 桌面端：自动下载 PNG
    ↓
复制分享链接（可选）
```

---

## 7. 注意事项

### 7.1 性能优化

- 卡片渲染使用 `visibility: hidden` 隐藏，避免布局抖动
- 图片生成在用户点击保存时才执行，不预先生成
- 用户头像等外部图片需配置 CORS

### 7.2 兼容性

- iOS Safari 不支持 `navigator.share` 分享文件，需提示长按保存
- 微信内置浏览器限制较多，建议展示图片让用户手动长按

### 7.3 二维码生成

使用 `qrcode.react` 库生成小程序码/网页二维码：

```tsx
import { QRCodeSVG } from "qrcode.react";

<QRCodeSVG
    value={`https://coachlink.app/share/training/${shareToken}`}
    size={64}
    bgColor="transparent"
    fgColor="#ffffff"
/>;
```

---

## 8. 工作量详细拆分

| 任务                      | 时间     |
| ------------------------- | -------- |
| 数据库迁移（share_token） | 0.5h     |
| share-info API            | 1h       |
| 公开分享页 API            | 1h       |
| DataFlowCard 组件         | 1.5h     |
| CalendarCard 组件         | 1.5h     |
| MinimalCard 组件          | 1h       |
| ShareCardModal 容器       | 1h       |
| useCardGenerator Hook     | 1.5h     |
| 公开分享页 UI             | 2h       |
| 测试与调优                | 1h       |
| **合计**                  | **~12h** |
