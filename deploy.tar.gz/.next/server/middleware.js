var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__90a1d71f._.js")
R.c("server/chunks/[root-of-the-server]__bc022e48._.js")
R.m(489997)
module.exports=R.m(489997).exports
