(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["chunks/_next-internal_server_app_api_og_leaderboard_route_actions_9ae4d09e.js",486040,(a,e,_)=>{}]);

//# sourceMappingURL=_next-internal_server_app_api_og_leaderboard_route_actions_9ae4d09e.js.map