globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d0c683c2b780911d.js",
    "static/chunks/38535876f3f70db9.js",
    "static/chunks/e527c397bcdc6253.js",
    "static/chunks/89c3948195c0fca1.js",
    "static/chunks/8b181cdae656a3a3.js",
    "static/chunks/turbopack-f617b45b061af260.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];