module.exports=[911393,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_user_delete-video-collection_route_actions_efa39bdf.js.map