module.exports=[953369,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_user_update-video-collection_route_actions_7f8ea196.js.map