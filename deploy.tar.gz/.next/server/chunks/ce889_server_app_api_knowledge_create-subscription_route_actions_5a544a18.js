module.exports=[953747,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_knowledge_create-subscription_route_actions_5a544a18.js.map