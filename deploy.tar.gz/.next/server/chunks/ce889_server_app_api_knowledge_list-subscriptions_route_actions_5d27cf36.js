module.exports=[388186,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_knowledge_list-subscriptions_route_actions_5d27cf36.js.map