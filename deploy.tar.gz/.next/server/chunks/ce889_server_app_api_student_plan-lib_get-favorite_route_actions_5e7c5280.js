module.exports=[553831,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_get-favorite_route_actions_5e7c5280.js.map