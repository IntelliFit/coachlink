module.exports=[721624,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_list-favorites_route_actions_1ea959da.js.map