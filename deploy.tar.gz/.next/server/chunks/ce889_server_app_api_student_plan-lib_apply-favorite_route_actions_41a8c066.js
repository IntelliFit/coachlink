module.exports=[278669,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_apply-favorite_route_actions_41a8c066.js.map