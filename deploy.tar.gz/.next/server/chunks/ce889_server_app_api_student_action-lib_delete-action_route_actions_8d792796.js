module.exports=[943998,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_action-lib_delete-action_route_actions_8d792796.js.map