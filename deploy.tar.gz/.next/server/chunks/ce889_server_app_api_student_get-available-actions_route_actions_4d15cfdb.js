module.exports=[824037,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_get-available-actions_route_actions_4d15cfdb.js.map