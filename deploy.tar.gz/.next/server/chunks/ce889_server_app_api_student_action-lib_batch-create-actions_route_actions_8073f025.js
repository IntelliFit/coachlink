module.exports=[604580,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_action-lib_batch-create-actions_route_actions_8073f025.js.map