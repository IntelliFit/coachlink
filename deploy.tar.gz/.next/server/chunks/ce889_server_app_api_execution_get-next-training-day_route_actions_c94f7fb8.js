module.exports=[536342,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_execution_get-next-training-day_route_actions_c94f7fb8.js.map