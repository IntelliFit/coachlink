module.exports=[460534,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_get-current_route_actions_daa02738.js.map