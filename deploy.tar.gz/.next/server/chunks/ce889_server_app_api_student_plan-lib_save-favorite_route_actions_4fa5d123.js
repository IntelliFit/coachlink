module.exports=[426167,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_save-favorite_route_actions_4fa5d123.js.map