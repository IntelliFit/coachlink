module.exports=[410225,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_action-lib_list-coach-actions_route_actions_ca5a0085.js.map