module.exports=[102980,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_user_add-video-to-collection_route_actions_95fe4a94.js.map