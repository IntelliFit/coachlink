module.exports=[6647,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_user_update-training-reminder_route_actions_f87c1fba.js.map