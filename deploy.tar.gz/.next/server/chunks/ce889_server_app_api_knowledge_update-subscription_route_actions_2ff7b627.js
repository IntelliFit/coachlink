module.exports=[841395,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_knowledge_update-subscription_route_actions_2ff7b627.js.map