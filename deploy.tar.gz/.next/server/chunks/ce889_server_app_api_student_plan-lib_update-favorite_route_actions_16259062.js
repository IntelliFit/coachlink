module.exports=[36427,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_update-favorite_route_actions_16259062.js.map