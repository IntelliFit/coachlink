module.exports=[930274,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_list-history_route_actions_43e47438.js.map