module.exports=[296540,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_action-lib_list-actions_route_actions_d1f7771b.js.map