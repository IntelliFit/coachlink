module.exports=[158861,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_student_plan-lib_delete-favorite_route_actions_9493d182.js.map